DROP TABLE inventoryitem;
Drop TABLE inventory;
DROP TABLE user;

