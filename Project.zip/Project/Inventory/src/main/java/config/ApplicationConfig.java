package config;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import org.jboss.resteasy.plugins.interceptors.CorsFilter;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import rest.AuthenticateService;
import rest.InventoryItemService;
import rest.InventoryService;

@ApplicationPath("")
public class ApplicationConfig extends Application {
	 	private Set<Object> singletons = new HashSet<Object>();
	   private Set<Class<?>> classes = new HashSet<Class<?>>();

	public ApplicationConfig() {
		classes.add(AuthenticateService.class);
		classes.add(InventoryService.class);
		classes.add(InventoryItemService.class);
	}
	
/*	@Override
	public Set<Object> getSingletons() {
		if (singletons == null) {
			CorsFilter corsFilter = new CorsFilter();
			corsFilter.getAllowedOrigins().add("*");

			singletons = new LinkedHashSet<Object>();
			singletons.add(corsFilter);
		}
		return singletons;
	}*/
	
	 @Override
	   public Set<Class<?>> getClasses() {
	        return classes;
	    }

	   @Override
	   public Set<Object> getSingletons() {
	        return singletons;
	   }
}