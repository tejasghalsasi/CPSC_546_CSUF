import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css']
})
export class FeaturesComponent implements OnInit {
	private id;
  constructor(private route: ActivatedRoute) {}

    ngOnInit() {
  }

   ngOnDestroy() {

  }

}
